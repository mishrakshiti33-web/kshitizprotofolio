# GeoGuard AI — Emergency Operational Terminal

GeoGuard AI is a real-time emergency advisory and ground-truth consensus matrix engineered for immediate crisis management during severe natural disasters (landslides, flash floods, earthquakes).

Built specifically for high-stress scenarios, GeoGuard AI strips away non-essential UI visual clutter to prioritize zero-fluff, actionable physical directives, live atmospheric & seismic telemetry streaming, and a peer-verified human-in-the-loop safety net.

---

## Key Features

- **Zero-Fluff AI Operational Director:** Utilizes the Google Gemini API with strict system instructions to deliver step-by-step physical action items without conversational filler, greetings, or dangerous hallucinations.
- **Live Dual-Telemetry Stream:** Queries USGS real-time seismic wave data and Open-Meteo atmospheric metrics concurrently upon location lock.
- **Human-in-the-Loop Consensus Matrix:** When 3 independent ground reports are logged within a 10km radius, local ground truth overrides satellite sensor data.
- **Automated Low-Latency Alerts:** Integrates with the Resend API to automatically dispatch emergency email notifications to municipal administrators and school principals when a consensus threshold is met.
- **High-Contrast Responsive UI:** Desktop-first 2-column operational terminal that seamlessly collapses into a single-column, one-handed mobile UI.

---

## Architecture Overview

```text
geoguard-ai/
├── package.json
├── .env.example
├── README.md
├── server.js
└── public/
    ├── index.html
    ├── styles.css
    └── app.js
```

---

## Quick Start & Local Setup

### Prerequisites
- [Node.js](https://nodejs.org/) (v18 or higher)
- Google Gemini API Key
- Resend API Key (Optional for email alerts)

### Installation

1. **Clone the Repository:**
   ```bash
   git clone https://github.com/your-username/geoguard-ai.git
   cd geoguard-ai
   ```

2. **Install Dependencies:**
   ```bash
   npm install
   ```

3. **Configure Environment Variables:**
   Copy `.env.example` to `.env` and fill in your API credentials:
   ```bash
   cp .env.example .env
   ```
   Edit `.env`:
   ```env
   PORT=3000
   GEMINI_API_KEY=your_gemini_api_key_here
   RESEND_API_KEY=your_resend_api_key_here
   ALERT_RECIPIENT_EMAIL=admin@localcommunity.gov.np
   ```

4. **Launch the Server:**
   ```bash
   npm start
   ```
   Open your browser and navigate to `http://localhost:3000`.

---

## API Endpoints

### `POST /api/advisory`
Calculates crisis directives by combining GPS coordinates, user scenario, live weather/earthquake telemetry, and ground-truth override checks.

### `POST /api/report-hazard`
Logs a peer report in the ground-truth consensus engine. Automatically triggers a Resend email dispatch upon reaching 3 matching local submissions.

---

## License

MIT License — Built with community protection and open-source accessibility in mind.
