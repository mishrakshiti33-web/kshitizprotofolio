let userLocation = null;

const gpsBtn = document.getElementById('gps-btn');
const gpsStatus = document.getElementById('gps-status');
const requestAdvisoryBtn = document.getElementById('request-advisory-btn');
const situationInput = document.getElementById('situation-input');
const aiOutput = document.getElementById('ai-output');

const telemetryRain = document.getElementById('telemetry-rain');
const telemetryWind = document.getElementById('telemetry-wind');
const telemetrySeismic = document.getElementById('telemetry-seismic');

const hazardSelect = document.getElementById('hazard-type');
const reportBtn = document.getElementById('report-btn');
const matrixStatus = document.getElementById('matrix-status');

// 1. HTML5 Geolocation API Integration
gpsBtn.addEventListener('click', () => {
  if (!navigator.geolocation) {
    gpsStatus.innerText = "Geolocation not supported by this browser.";
    return;
  }

  gpsStatus.innerText = "Locking satellite coordinates...";
  
  navigator.geolocation.getCurrentPosition(
    (position) => {
      userLocation = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude
      };
      gpsStatus.className = "alert-box active";
      gpsStatus.innerText = `GPS LOCKED: ${userLocation.latitude.toFixed(4)}, ${userLocation.longitude.toFixed(4)}`;
    },
    (err) => {
      gpsStatus.innerText = `GPS ERROR: ${err.message}`;
    },
    { enableHighAccuracy: true, timeout: 10000 }
  );
});

// 2. Query Gemini Operational Director API
requestAdvisoryBtn.addEventListener('click', async () => {
  if (!userLocation) {
    alert("Must lock GPS coordinates before requesting crisis advisory.");
    return;
  }

  aiOutput.innerText = "STREAMING DIRECTIVE FROM GEOGUARD AI DIRECTOR...";

  try {
    const res = await fetch('/api/advisory', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        customSituation: situationInput.value
      })
    });

    const data = await res.json();
    aiOutput.innerText = data.advisory;

    // Render Live Telemetry Stream
    if (data.telemetry && data.telemetry.weather) {
      telemetryRain.innerText = `${data.telemetry.weather.rain || 0} mm`;
      telemetryWind.innerText = `${data.telemetry.weather.wind_speed_10m || 0} km/h`;
    }
    if (data.telemetry && data.telemetry.seismic) {
      telemetrySeismic.innerText = typeof data.telemetry.seismic === 'object' 
        ? `M ${data.telemetry.seismic.mag} - ${data.telemetry.seismic.place}`
        : 'None Near';
    }

    // Render Override Warnings
    if (data.activeOverrides && data.activeOverrides.length > 0) {
      matrixStatus.innerText = `CRITICAL CONSENSUS OVERRIDE ACTIVE:\n${data.activeOverrides.join('\n')}`;
      matrixStatus.style.color = "#da3633";
    }

  } catch (err) {
    aiOutput.innerText = "NETWORK ERROR: Emergency directive stream failed. Head to high ground immediately.";
  }
});

// 3. Submit Ground Truth Report
reportBtn.addEventListener('click', async () => {
  if (!userLocation) {
    alert("Must lock GPS coordinates to file an verified ground report.");
    return;
  }

  try {
    const res = await fetch('/api/report-hazard', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        hazardType: hazardSelect.value
      })
    });

    const data = await res.json();
    matrixStatus.innerText = `Report transmitted. (${data.count}/${data.threshold} verified reports in area for consensus alert execution).`;
  } catch (err) {
    alert("Failed to submit ground truth report.");
  }
});
