require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { GoogleGenAI } = require('@google/genai');
const { Resend } = require('resend');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Initialize Services
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
const resend = new Resend(process.env.RESEND_API_KEY || '');

// In-Memory Database for Ground Truth Consensus Matrix
const groundReports = [];
const VERIFICATION_THRESHOLD = 3;

/**
 * System Instruction for Utilitarian Emergency Advisory
 */
const EMERGENCY_SYSTEM_INSTRUCTION = `
You are the GeoGuard AI Emergency Operational Director.
Your sole purpose is to provide immediate, actionable, life-saving instructions to people during active natural disasters (landslides, flash floods, earthquakes).

RULES:
1. NO conversational filler, greetings, pleasantries, or meta-commentary.
2. Direct, clear, step-by-step physical action items only.
3. Keep response concise (max 150 words). Use bullet points.
4. If ground-truth consensus (3+ reports) overrides telemetry, prioritize immediate evacuation advice based on ground truth.
`;

// Helper: Query Open-Meteo & USGS API
async function fetchTelemetry(lat, lon) {
  try {
    const weatherRes = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,rain,showers,wind_speed_10m`
    );
    const weatherData = await weatherRes.json();

    const usgsRes = await fetch(
      `https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&latitude=${lat}&longitude=${lon}&maxradiuskm=200&limit=1`
    );
    const usgsData = await usgsRes.json();
    const nearestQuake = usgsData.features?.[0]?.properties || null;

    return {
      weather: weatherData.current || {},
      seismic: nearestQuake ? { mag: nearestQuake.mag, place: nearestQuake.place, time: nearestQuake.time } : "No recent seismic activity detected within 200km."
    };
  } catch (err) {
    console.error("Telemetry fetch error:", err);
    return { weather: "Telemetry unavailable", seismic: "Telemetry unavailable" };
  }
}

// API: Process Crisis Advisory Request
app.post('/api/advisory', async (req, res) => {
  const { latitude, longitude, customSituation } = req.body;

  if (!latitude || !longitude) {
    return res.status(400).json({ error: "Latitude and longitude are required." });
  }

  // 1. Fetch Real-Time Atmospheric & Seismic Telemetry
  const telemetry = await fetchTelemetry(latitude, longitude);

  // 2. Check Ground Truth Matrix within ~10km radius
  const localReports = groundReports.filter(r => {
    const dLat = Math.abs(r.latitude - latitude);
    const dLon = Math.abs(r.longitude - longitude);
    return dLat < 0.1 && dLon < 0.1;
  });

  const verifiedGroundHazards = {};
  localReports.forEach(r => {
    verifiedGroundHazards[r.hazardType] = (verifiedGroundHazards[r.hazardType] || 0) + 1;
  });

  const activeOverrides = Object.entries(verifiedGroundHazards)
    .filter(([_, count]) => count >= VERIFICATION_THRESHOLD)
    .map(([hazard, count]) => `${hazard.toUpperCase()} (Confirmed by ${count} independent local sources)`);

  // 3. Construct Context for AI Director
  const promptContext = `
USER COORDINATES: Lat ${latitude}, Lon ${longitude}
USER SITUATION: ${customSituation || "Standard emergency status query"}
SATELLITE/SENSOR TELEMETRY: ${JSON.stringify(telemetry)}
GROUND-TRUTH OVERRIDES (HUMAN CONSENSUS): ${activeOverrides.length > 0 ? activeOverrides.join(', ') : "None verified yet"}

Formulate urgent operational directives for the user:
`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: promptContext,
      config: {
        systemInstruction: EMERGENCY_SYSTEM_INSTRUCTION,
        temperature: 0.2
      }
    });

    res.json({
      advisory: response.text,
      telemetry,
      activeOverrides
    });
  } catch (err) {
    console.error("Gemini API Error:", err);
    res.status(500).json({ advisory: "CRITICAL: Move to higher ground immediately away from riverbeds and steep slopes. AI Directives currently running in fallback mode." });
  }
});

// API: Ground-Truth Report Submission & Low-Latency Dispatch
app.post('/api/report-hazard', async (req, res) => {
  const { latitude, longitude, hazardType, reporterName } = req.body;

  if (!latitude || !longitude || !hazardType) {
    return res.status(400).json({ error: "Missing report parameters." });
  }

  const report = {
    id: Date.now().toString(),
    latitude: parseFloat(latitude),
    longitude: parseFloat(longitude),
    hazardType,
    reporterName: reporterName || "Anonymous Local Citizen",
    timestamp: new Date().toISOString()
  };

  groundReports.push(report);

  // Check matching reports in area
  const matchingCount = groundReports.filter(r => 
    r.hazardType === hazardType &&
    Math.abs(r.latitude - report.latitude) < 0.1 &&
    Math.abs(r.longitude - report.longitude) < 0.1
  ).length;

  // Trigger Low-Latency Resend Alert on Consensus Threshold reached
  if (matchingCount === VERIFICATION_THRESHOLD) {
    try {
      if (process.env.RESEND_API_KEY) {
        await resend.emails.send({
          from: 'GeoGuard AI Alert <alerts@geoguard.local>',
          to: [process.env.ALERT_RECIPIENT_EMAIL || 'admin@localcommunity.gov.np'],
          subject: `CRITICAL ALERT: Ground-Truth Consensus - ${hazardType.toUpperCase()}`,
          html: `
            <h2>CRITICAL EMERGENCY ALERT - GEOGUARD MATRIX</h2>
            <p><strong>Hazard Type:</strong> ${hazardType.toUpperCase()}</p>
            <p><strong>Coordinates:</strong> ${latitude}, ${longitude}</p>
            <p><strong>Status:</strong> Verified by ${VERIFICATION_THRESHOLD} independent local reports within immediate geographic radius.</p>
            <p>Satellite telemetry overridden by ground truth. Take immediate community safety action.</p>
          `
        });
        console.log(`Resend notification dispatched for ${hazardType}`);
      }
    } catch (emailErr) {
      console.error("Resend API Email Failed:", emailErr);
    }
  }

  res.json({ success: true, count: matchingCount, threshold: VERIFICATION_THRESHOLD });
});

app.listen(PORT, () => {
  console.log(`[GeoGuard AI Terminal Operating on Port ${PORT}]`);
});
