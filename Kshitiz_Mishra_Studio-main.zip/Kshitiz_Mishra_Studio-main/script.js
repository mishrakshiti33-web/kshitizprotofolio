/* ═══════════════════════════════════════════════════════════
   KSHITIZ MISHRA STUDIO — Premium JavaScript
   ═══════════════════════════════════════════════════════════ */

'use strict';

/* ── Helpers ───────────────────────────────────────────── */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];
const on = (el, ev, fn, opts) => el && el.addEventListener(ev, fn, opts);

/* ═══════════════════════════════════════════════════════════
   LOADER
═══════════════════════════════════════════════════════════ */
(function initLoader() {
  const loader = $('#loader');
  const bar    = $('#loaderBar');
  const text   = $('#loaderText');
  if (!loader) return;

  document.body.classList.add('loading');
  let progress = 0;

  const messages = ['Loading Experience...', 'Crafting Pixels...', 'Almost Ready...'];
  let msgIndex = 0;

  const tick = setInterval(() => {
    progress += Math.random() * 18 + 4;
    if (progress >= 100) { progress = 100; clearInterval(tick); }
    bar.style.width = progress + '%';

    if (progress > 40 && msgIndex === 0) { msgIndex = 1; text.textContent = messages[1]; }
    if (progress > 75 && msgIndex === 1) { msgIndex = 2; text.textContent = messages[2]; }

    if (progress >= 100) {
      setTimeout(() => {
        loader.classList.add('hidden');
        document.body.classList.remove('loading');
        initReveal();
        initHeroAnimations();
      }, 300);
    }
  }, 60);
})();

/* ═══════════════════════════════════════════════════════════
   CUSTOM CURSOR (desktop only)
═══════════════════════════════════════════════════════════ */
(function initCursor() {
  if (window.matchMedia('(hover: none)').matches) return;

  const cursor   = $('#cursor');
  const follower = $('#cursorFollower');
  if (!cursor || !follower) return;

  let mx = 0, my = 0, fx = 0, fy = 0;

  on(document, 'mousemove', e => { mx = e.clientX; my = e.clientY; });

  function animateCursor() {
    cursor.style.left   = mx + 'px';
    cursor.style.top    = my + 'px';

    fx += (mx - fx) * 0.12;
    fy += (my - fy) * 0.12;
    follower.style.left = fx + 'px';
    follower.style.top  = fy + 'px';

    requestAnimationFrame(animateCursor);
  }
  animateCursor();

  const hoverTargets = 'a, button, .service-card, .portfolio-card, .filter-btn, .magnetic, input, textarea, select';

  on(document, 'mouseover', e => {
    if (e.target.closest(hoverTargets)) {
      cursor.classList.add('cursor-hover');
      follower.classList.add('cursor-hover');
    }
  });

  on(document, 'mouseout', e => {
    if (e.target.closest(hoverTargets)) {
      cursor.classList.remove('cursor-hover');
      follower.classList.remove('cursor-hover');
    }
  });

  on(document, 'mousedown', () => cursor.classList.add('cursor-click'));
  on(document, 'mouseup', () => cursor.classList.remove('cursor-click'));
})();

/* ═══════════════════════════════════════════════════════════
   NAVIGATION
═══════════════════════════════════════════════════════════ */
(function initNav() {
  const nav          = $('#nav');
  const hamburger    = $('#hamburger');
  const mobileMenu   = $('#mobileMenu');
  const mobileOverlay = $('#mobileOverlay');
  const mobileClose  = $('#mobileMenuClose');
  const mobileLinks  = $$('.mobile-link');
  const navLinks     = $$('.nav-link');

  /* Scroll glass effect */
  function onScroll() {
    nav.classList.toggle('scrolled', window.scrollY > 24);
  }
  on(window, 'scroll', onScroll, { passive: true });
  onScroll();

  /* Mobile menu */
  function openMenu() {
    mobileMenu.classList.add('open');
    mobileOverlay.classList.add('active');
    hamburger.classList.add('open');
    hamburger.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  }

  function closeMenu() {
    mobileMenu.classList.remove('open');
    mobileOverlay.classList.remove('active');
    hamburger.classList.remove('open');
    hamburger.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  }

  on(hamburger, 'click', openMenu);
  on(mobileClose, 'click', closeMenu);
  on(mobileOverlay, 'click', closeMenu);
  mobileLinks.forEach(l => on(l, 'click', closeMenu));

  /* Active nav link on scroll */
  const sections = $$('section[id]');

  function updateActiveLink() {
    const scrollY = window.scrollY + 100;
    let current = '';

    sections.forEach(s => {
      if (scrollY >= s.offsetTop) current = s.id;
    });

    navLinks.forEach(l => {
      l.classList.toggle('active', l.dataset.section === current);
    });
  }

  on(window, 'scroll', updateActiveLink, { passive: true });

  /* Smooth anchor scroll */
  $$('a[href^="#"]').forEach(a => {
    on(a, 'click', e => {
      const target = $(a.getAttribute('href'));
      if (!target) return;
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });
})();

/* ═══════════════════════════════════════════════════════════
   SCROLL REVEAL
═══════════════════════════════════════════════════════════ */
function initReveal() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  $$('.reveal-up, .reveal-right, .reveal-left').forEach(el => observer.observe(el));
}

/* ═══════════════════════════════════════════════════════════
   HERO — PARTICLE CANVAS
═══════════════════════════════════════════════════════════ */
function initHeroAnimations() {
  const canvas = $('#particleCanvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  let W, H, particles;

  function resize() {
    W = canvas.width  = canvas.offsetWidth;
    H = canvas.height = canvas.offsetHeight;
    createParticles();
  }

  function createParticles() {
    const count = Math.floor((W * H) / 14000);
    particles = Array.from({ length: count }, () => ({
      x:  Math.random() * W,
      y:  Math.random() * H,
      r:  Math.random() * 1.5 + 0.4,
      dx: (Math.random() - 0.5) * 0.35,
      dy: (Math.random() - 0.5) * 0.35,
      a:  Math.random() * 0.5 + 0.1,
    }));
  }

  function drawParticles() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(96, 165, 250, ${p.a})`;
      ctx.fill();

      p.x += p.dx;
      p.y += p.dy;
      if (p.x < 0 || p.x > W) p.dx *= -1;
      if (p.y < 0 || p.y > H) p.dy *= -1;
    });

    /* Connect nearby particles */
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 100) {
          ctx.beginPath();
          ctx.strokeStyle = `rgba(59, 130, 246, ${0.12 * (1 - dist / 100)})`;
          ctx.lineWidth = 0.5;
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.stroke();
        }
      }
    }

    requestAnimationFrame(drawParticles);
  }

  resize();
  on(window, 'resize', resize);
  drawParticles();
}

/* ═══════════════════════════════════════════════════════════
   MOUSE-FOLLOW GLOW on Hero
═══════════════════════════════════════════════════════════ */
(function initHeroGlow() {
  const hero = $('.hero');
  if (!hero || window.matchMedia('(hover: none)').matches) return;

  on(hero, 'mousemove', e => {
    const rect = hero.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width)  * 100;
    const y = ((e.clientY - rect.top)  / rect.height) * 100;
    hero.style.setProperty('--gx', x + '%');
    hero.style.setProperty('--gy', y + '%');
  });
})();

/* ═══════════════════════════════════════════════════════════
   MAGNETIC BUTTONS
═══════════════════════════════════════════════════════════ */
(function initMagnetic() {
  if (window.matchMedia('(hover: none)').matches) return;

  $$('.magnetic').forEach(btn => {
    on(btn, 'mousemove', e => {
      const rect   = btn.getBoundingClientRect();
      const cx     = rect.left + rect.width  / 2;
      const cy     = rect.top  + rect.height / 2;
      const dx     = (e.clientX - cx) * 0.25;
      const dy     = (e.clientY - cy) * 0.25;
      btn.style.transform = `translate(${dx}px, ${dy}px)`;
    });

    on(btn, 'mouseleave', () => {
      btn.style.transform = '';
    });
  });
})();

/* ═══════════════════════════════════════════════════════════
   RIPPLE EFFECT
═══════════════════════════════════════════════════════════ */
on(document, 'click', e => {
  const btn = e.target.closest('.ripple');
  if (!btn) return;

  const rect   = btn.getBoundingClientRect();
  const circle = document.createElement('span');
  const size   = Math.max(rect.width, rect.height);

  circle.className = 'ripple-circle';
  circle.style.cssText = `
    width: ${size}px; height: ${size}px;
    left: ${e.clientX - rect.left - size / 2}px;
    top:  ${e.clientY - rect.top  - size / 2}px;
  `;

  btn.appendChild(circle);
  on(circle, 'animationend', () => circle.remove());
});

/* ═══════════════════════════════════════════════════════════
   PORTFOLIO FILTER
═══════════════════════════════════════════════════════════ */
(function initPortfolioFilter() {
  const filterBtns = $$('.filter-btn');
  const cards      = $$('.portfolio-card');

  filterBtns.forEach(btn => {
    on(btn, 'click', () => {
      const filter = btn.dataset.filter;

      filterBtns.forEach(b => {
        b.classList.remove('active');
        b.setAttribute('aria-selected', 'false');
      });
      btn.classList.add('active');
      btn.setAttribute('aria-selected', 'true');

      cards.forEach(card => {
        const cats = card.dataset.category || '';
        const show = filter === 'all' || cats.split(' ').includes(filter);

        if (show) {
          card.classList.remove('hidden');
          card.style.animation = 'filterReveal 0.4s ease forwards';
        } else {
          card.classList.add('hidden');
        }
      });
    });
  });

  /* Inject keyframe once */
  const style = document.createElement('style');
  style.textContent = `@keyframes filterReveal { from { opacity:0; transform:scale(0.95); } to { opacity:1; transform:scale(1); } }`;
  document.head.appendChild(style);
})();

/* ═══════════════════════════════════════════════════════════
   CARD TILT EFFECT (3D hover)
═══════════════════════════════════════════════════════════ */
(function initTilt() {
  if (window.matchMedia('(hover: none)').matches) return;

  $$('[data-tilt]').forEach(card => {
    on(card, 'mousemove', e => {
      const rect = card.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width  - 0.5;
      const y = (e.clientY - rect.top)  / rect.height - 0.5;
      card.style.transform = `perspective(800px) rotateY(${x * 8}deg) rotateX(${-y * 8}deg) translateZ(8px)`;
    });

    on(card, 'mouseleave', () => {
      card.style.transform = '';
    });
  });
})();

/* ═══════════════════════════════════════════════════════════
   COPY EMAIL — direct-contact panel (no form; mailto only)
═══════════════════════════════════════════════════════════ */
(function initCopyEmail() {
  const btn      = $('#copyEmailBtn');
  const btnText  = $('#copyEmailBtnText');
  const status   = $('#copyEmailStatus');
  if (!btn) return;

  const email        = 'studio@kshitizmishra.dev';
  const defaultLabel = btnText ? btnText.textContent : 'Copy email address';
  let resetTimer;

  async function copyEmail() {
    try {
      await navigator.clipboard.writeText(email);
    } catch (err) {
      /* Clipboard API unavailable (e.g. insecure context) — fall back silently */
      if (status) status.textContent = 'Copy failed. Please select the address manually.';
      return;
    }

    btn.classList.add('copied');
    if (btnText) btnText.textContent = 'Copied to clipboard';
    if (status) status.textContent = 'Email address copied to clipboard.';

    clearTimeout(resetTimer);
    resetTimer = setTimeout(() => {
      btn.classList.remove('copied');
      if (btnText) btnText.textContent = defaultLabel;
    }, 2500);
  }

  on(btn, 'click', copyEmail);
})();

/* ═══════════════════════════════════════════════════════════
   COOKIE BANNER
═══════════════════════════════════════════════════════════ */
(function initCookies() {
  const banner  = $('#cookieBanner');
  const accept  = $('#cookieAccept');
  const decline = $('#cookieDecline');
  if (!banner) return;

  if (localStorage.getItem('km-cookie-consent')) return;

  setTimeout(() => banner.classList.add('visible'), 2500);

  function dismiss(choice) {
    localStorage.setItem('km-cookie-consent', choice);
    banner.style.transition = 'transform 0.5s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.4s';
    banner.style.transform  = 'translateX(-50%) translateY(120px)';
    banner.style.opacity    = '0';
    setTimeout(() => banner.remove(), 500);
  }

  on(accept,  'click', () => dismiss('accepted'));
  on(decline, 'click', () => dismiss('declined'));
})();

/* ═══════════════════════════════════════════════════════════
   THEME TOGGLE
═══════════════════════════════════════════════════════════ */
(function initTheme() {
  const toggle = $('#themeToggle');
  const html   = document.documentElement;

  const saved = localStorage.getItem('km-theme') || 'dark';
  html.setAttribute('data-theme', saved);

  on(toggle, 'click', () => {
    const next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', next);
    localStorage.setItem('km-theme', next);
  });
})();

/* ═══════════════════════════════════════════════════════════
   BACK TO TOP
═══════════════════════════════════════════════════════════ */
(function initBackToTop() {
  const btn = $('#backToTop');
  if (!btn) return;

  on(window, 'scroll', () => {
    btn.classList.toggle('visible', window.scrollY > 600);
  }, { passive: true });

  on(btn, 'click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
})();

/* ═══════════════════════════════════════════════════════════
   PARALLAX — Section backgrounds
═══════════════════════════════════════════════════════════ */
(function initParallax() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  if (window.matchMedia('(hover: none)').matches) return;

  const orbs = $$('.hero-orb, .about-orb, .contact-orb-1, .contact-orb-2');

  on(window, 'scroll', () => {
    const y = window.scrollY;
    orbs.forEach((orb, i) => {
      const speed = (i % 2 === 0 ? 0.04 : 0.06);
      orb.style.transform = `translateY(${y * speed}px)`;
    });
  }, { passive: true });
})();

/* ═══════════════════════════════════════════════════════════
   FOOTER YEAR
═══════════════════════════════════════════════════════════ */
(function setFooterYear() {
  const el = $('#footerYear');
  if (el) el.textContent = new Date().getFullYear();
})();

/* ═══════════════════════════════════════════════════════════
   ANIMATED TEXT GRADIENT on Hero Headline
═══════════════════════════════════════════════════════════ */
(function initGradientShift() {
  const accent = $('.hero-accent');
  if (!accent || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  let hue = 210;
  function shift() {
    hue = (hue + 0.15) % 360;
    accent.style.backgroundImage = `linear-gradient(135deg, hsl(${hue}, 90%, 70%), hsl(${(hue + 40) % 360}, 80%, 60%))`;
    requestAnimationFrame(shift);
  }
  shift();
})();

/* ═══════════════════════════════════════════════════════════
   PROCESS STEP — animated connector
═══════════════════════════════════════════════════════════ */
(function initProcessConnector() {
  const connectors = $$('.process-connector');
  if (!connectors.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.background = 'linear-gradient(90deg, rgba(59,130,246,0.3), var(--accent), rgba(59,130,246,0.3))';
        entry.target.style.boxShadow  = '0 0 12px rgba(59,130,246,0.4)';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  connectors.forEach(c => observer.observe(c));
})();

/* ═══════════════════════════════════════════════════════════
   HERO BADGE — cycle text
═══════════════════════════════════════════════════════════ */
(function initBadgeCycle() {
  const badge = $('.hero-badge');
  if (!badge) return;

  const states = [
    'Available for New Projects',
    'Based in India · Working Globally',
    'Designing Digital Experiences',
  ];

  let index = 0;
  const textNode = badge.lastChild;
  if (!textNode) return;

  setInterval(() => {
    index = (index + 1) % states.length;
    badge.style.opacity = '0';
    badge.style.transform = 'translateY(4px)';
    badge.style.transition = 'opacity 0.3s, transform 0.3s';

    setTimeout(() => {
      badge.childNodes[badge.childNodes.length - 1].textContent = states[index];
      badge.style.opacity = '1';
      badge.style.transform = 'translateY(0)';
    }, 300);
  }, 3500);
})();

/* ═══════════════════════════════════════════════════════════
   LAZY IMAGE OBSERVER
═══════════════════════════════════════════════════════════ */
(function initLazyImages() {
  const imgs = $$('img[loading="lazy"]');
  if (!('IntersectionObserver' in window)) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        img.classList.add('img-loaded');
        observer.unobserve(img);
      }
    });
  }, { rootMargin: '200px' });

  imgs.forEach(img => {
    img.style.transition = 'opacity 0.5s ease';
    img.style.opacity    = '0';
    on(img, 'load', () => { img.style.opacity = '1'; });
    if (img.complete) { img.style.opacity = '1'; }
    observer.observe(img);
  });
})();

/* ═══════════════════════════════════════════════════════════
   KEYBOARD NAVIGATION — mobile menu
═══════════════════════════════════════════════════════════ */
on(document, 'keydown', e => {
  if (e.key === 'Escape') {
    const mobileMenu = $('#mobileMenu');
    if (mobileMenu && mobileMenu.classList.contains('open')) {
      mobileMenu.classList.remove('open');
      $('#mobileOverlay').classList.remove('active');
      $('#hamburger').classList.remove('open');
      $('#hamburger').setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    }
  }
});
